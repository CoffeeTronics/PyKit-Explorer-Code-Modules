# Role and Responsibilities

**Title:** Senior Engineer, Academic Program
**Organization:** Microchip Technology Inc
**Reports to:** Manager, Academic Program
**Direct reports:** Interns (variable)

## Core Responsibilities

- Design, test, and bring to market academic development kits, baseboards, and hardware 
  for students and makers
- Develop firmware, software, and high-level APIs that give students repeatable 
  "I just built something cool" moments in a 3-4 hour workshop
- Create workshop training materials thorough enough that anyone can run them unsupervised
- Work with high school and university teachers on curriculum strategies to reduce 
  first/second-year attrition in engineering programs
- Represent Microchip at trade shows and Maker Faire events
- Communicate to academic partners what industry actually wants from new graduates

## Regular Decisions

- What projects and builds to put in front of students
- How to sequence and frame technical topics to avoid students self-selecting out of engineering
- What to assign interns — challenging enough to grow them, scoped so they're not overwhelmed

## Outputs

- Hardware development kits with accompanying software examples and student projects
- Workshop training materials (self-contained, no facilitator expertise required)
- Academic coordination deliverables — translating industry needs into curriculum input

## Cadences

- **Weekly:** Hardware development progress, teacher/professor meetings, event prep
- **Quarterly:** Trade show planning, student event scheduling, workshop calendar
- **Annually:** Full academic outreach planning cycle
- **5-year:** Strategic roadmap for the academic program (in progress)
