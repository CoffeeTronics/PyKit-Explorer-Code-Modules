# Identity

**Name:** Ross Satchell
**Role:** Senior Engineer, Academic Program
**Organization:** Microchip Technology Inc

## What I Do

I develop embedded systems development kits aimed at students and educators — hardware, 
firmware, and the workshops that go with them. A big part of my week is writing CircuitPython 
content, building demos for trade shows and Maker Faire, and getting in front of students to 
talk about embedded systems engineering as a career. I'm the bridge between Microchip's 
technology and the academic world.

## What I'm Known For

People come to me for anything touching academic outreach — CircuitPython, Makerspace culture, 
hardware kits for classrooms, workshop design, and increasingly, how to bring AI tools into 
engineering education. If it involves students, teachers, or makers, it lands on my desk.
