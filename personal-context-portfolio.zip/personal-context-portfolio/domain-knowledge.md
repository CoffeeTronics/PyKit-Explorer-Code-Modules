# Domain Knowledge

## Areas of Deep Expertise

- Bare metal C programming for embedded systems
- Electronics design — schematics and PCB layout through to manufacturable product
- Prototyping hardware while maintaining schematic discipline
- Modular, reusable code architecture
- Hardware and software debugging
- Workshop design for beginners — structuring a 3-4 hour session for maximum engagement 
  and minimum attrition
- Building physical things

## Daily Vocabulary — Don't Over-Explain

CircuitPython, MicroPython, bare metal, RTOS, Zephyr, MPLAB, GPIO, I2C, SPI, UART, BLE, 
IMU, PID loop, schematic capture, PCB layout, footprint, gerber, breakout board, baseboard, 
dev kit, UF2, REPL, pull request, git diff, Maker Faire, makerspace, hackathon, attrition, 
first-year engineering, STEM outreach, Arena, DTMFG portal.

## Industry Context an Outsider Wouldn't Know

- First and second year engineering attrition is a well-known crisis — students self-select 
  out before they ever reach the interesting parts of the degree
- CircuitPython is deliberately beginner-friendly but has real hardware limitations vs. C — 
  that tradeoff is a constant design consideration
- Maker Faire demos must be interactive, robust, and survive being handled by hundreds of 
  strangers — this is a hard engineering constraint, not a nice-to-have
- The gap between a working prototype and a manufacturable product is enormous — Arena, DTMFG 
  portals, and sign-off chains are the unglamorous reality of getting hardware to market
- Microchip's Ambassador network is a global distribution mechanism for academic outreach — 
  infrastructure, not marketing
- Students on Chromebooks is a real constraint in underfunded schools, not an edge case
- Every design decision is a tradeoff. Always find multiple solutions and pick the least 
  worst one

## Mental Models

- **Top-down design, bottom-up implementation** — design from the system level, build from 
  the component level
- **Minimum viable wow** — fastest path to a genuine "I built something real" moment, then 
  layer complexity
- **Floor vs. ceiling** — lower the entry barrier without limiting the upside
- **Protect the vision** — delegation and collaboration risk drift through accumulated 
  compromise; guard the original intent
- **Fail fast in hardware** — get a prototype in hand early; paper designs hide problems that 
  only appear when you build

## Where I'm a Beginner — Explain More, Not Less

- AI tools and workflows — still learning how to use them effectively
