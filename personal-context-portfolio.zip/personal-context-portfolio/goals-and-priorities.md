# Goals and Priorities

## Near-Term (This Quarter)

- PyKit Explorer available for sale
- Workshops running independently — kits shipping, Ambassadors facilitating, no dependency on me
- Interns growing and delivering

## Long-Term Vision

The Microchip Academic Program sits at a rare intersection: professional-grade hardware that 
makes abstract concepts physical, reach into universities, high schools, and maker communities 
globally, and people who can translate between the technical world and the human one.

The goal is to reach students who don't already know they want to be engineers. The student 
who grew up in a house where nobody went to university. The kid who always took things apart 
but was never told that's a skill. The barista who wonders if they could build a better PID 
controller. (That last one was me.)

**Concrete long-term pursuits:**

1. **Targeted outreach to underserved schools** — reaching students who don't have engineers 
   in the family modelling this path. Being the first time someone showed them the door.

2. **Accessible tooling floor** — the CircuitPython API is deliberately designed for students 
   who've only done intro Python. Lowering the floor without lowering the ceiling. Ensuring 
   the dev environment runs on Chromebooks — if it doesn't, we're filtering out the students 
   we most want to reach before they write a single line of code.

3. **Pima CC follow-up** — return with the updated API, but this time have students build 
   something themselves. Give them a problem space and tools, let them practice breaking an 
   ambitious idea into executable chunks. That process can only be learned by doing.

4. **National student hackathon** across all Ambassador partner schools simultaneously. 
   Identical hardware at every school — level playing field. Prize categories that reward 
   creativity, unexpected hardware use, and ambitious scope — not just polish. A student in 
   Chandler and a student in a rural school a thousand miles away, working with the same tools 
   at the same time, both discovering they can build something real.

## Tradeoff Orientation

- Quality over speed
- Long-term over short-term
- Starting with reach, building toward depth over time

## What I'm Deliberately Not Prioritizing

Proving ROI for the academic program. Drawing a clear line between student engagement and 
company profits is not meaningful or possible right now. The focus is long-term viability — 
for students and for Microchip.
