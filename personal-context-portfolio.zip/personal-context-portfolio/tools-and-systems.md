# Tools and Systems

## Daily Tools

- **CircuitPython** — primary firmware and scripting environment
- **VS Code** — main editor
- **Notepad++** — lightweight editing and scratch work

## VS Code Extensions

- Serial Monitor
- Claude Code
- MPLAB Code Configurator
- markdownlint
- MPLAB extension
- Workbench for Zephyr

## Data and Code Storage

- All repos live at `C:\GitRepos`
- Active development happens on the PyKit Explorer, typically mounted as `D:`
- Primary repo: `C:\GitRepos\PyKit-Explorer-Code-Modules`
- Working file is `D:\code.py` — note: Claude Code sometimes has difficulty directly 
  editing files at the root of `D:`, needs to be accounted for

## Known Workflow Friction

- No efficient diff/sync workflow yet between `D:\code.py` (device) and 
  `C:\GitRepos\PyKit-Explorer-Code-Modules` (local git repo). Needs solving.
- Improving Claude Code usage is an active goal — this portfolio is part of that. 
  Preference is for Claude to directly edit files rather than output code to copy-paste.

## Tools in Adoption

- **Zephyr RTOS** — planned for future embedded projects, will become a major part of the stack
- **MPLAB Tools / C/C++** — via VS Code MPLAB plugins, coming online alongside Zephyr

## Tools Evaluated and Rejected

None.
