# Preferences and Constraints

## Availability

- **Location:** Phoenix, AZ (MST/MDT)
- **Working hours:** Monday–Friday, 9am–5pm
- **Evenings and weekends:** Personal time. If work happens, time in lieu is taken.

## Non-Negotiables

- Academic kits must be approachable for beginners while remaining genuinely powerful 
  development tools. This tension is the whole point — do not collapse it in either direction.
- I maintain strong ownership over my work. I prefer to execute myself rather than delegate, 
  to protect the vision from dilution by compromise. An agent should support this, not route 
  around it.

## Things I Hate

- Meetings that should be emails
- Marketing fluff
- Corporate jargon
- Bullshit of any kind

## AI Output Preferences

- **Structure first.** Good output has a clear, logical flow — well-laid-out arguments that 
  build toward a point. Bad output waffles.
- **No filler.** If a sentence doesn't carry weight, cut it.
- **Match the register.** Engineer's voice. Direct. No inflation.
- **Default to bullet points** where structure allows; paragraphs only when detail requires it.
- **Length:** As long as needed, no longer.
