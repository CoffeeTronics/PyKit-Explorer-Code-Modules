# Team and Relationships

## Akram — Associate Director, Academic Program (Manager)
**Relationship:** Direct manager, servant leadership style
**Interaction:** Weekly 1-on-1s, face to face primarily, some email and Teams
**What he needs from me:** Progress updates on PyKit Explorer manufacturing, API and project 
examples, school and university visit updates, broader project status, moonshot ideas
**What I need from him:** Manufacturing roadblocks removed, travel approvals for workshops, 
trade shows, and school visits
**Agent notes:** Communicate progress and needs as concise bullet points. Nothing sensitive 
to navigate — straightforward working relationship.

## Benjamin — Technician, Dev Tools Manufacturing
**Relationship:** Manufacturing-side collaborator
**Interaction:** Mostly face to face, some email and Teams
**What I need from him:** Adding items to Arena and the DTMFG portal, navigating the 
manufacturing sign-off chain, identifying who to chase when things stall
**What he needs from me:** Nothing ongoing

## Jesus — Technician, PCB Layout
**Relationship:** PCB layout collaborator — a rockstar at layout
**Interaction:** Mostly face to face
**What I need from him:** PCB layout revisions
**What he needs from me:** Nothing ongoing

## Rodger — VP, Dev Tools
**Relationship:** Senior stakeholder, serious operator who gets things done
**Interaction:** Every ~2 weeks, face to face; often cc'd on relevant emails
**What he needs from me:** PyKit Explorer into active manufacturing
**What I need from him:** Sign-off on large payments, clearing major roadblocks

## Bob Martin — Mentor, Senior Technical Staff Engineer ("The Wizard of Make")
**Relationship:** Mentor — I'm often referred to as the Wizard's Apprentice
**Interaction:** Every ~2 weeks, informal
**What I need from him:** Advice when stuck, guidance on building things
**What he needs from me:** Updates on what I'm building and how it's going

## Megan & Kristin — Events Planners
**Relationship:** Event logistics coordinators
**Interaction:** Project-based around trade shows and Maker events
**What I need from them:** Ensuring demos and equipment actually arrive at events
**What they need from me:** Pre-event demo status updates and post-event reports

## David — Marcom Video Team
**Relationship:** Professional video and photography resource
**Interaction:** Project-based
**What I need from him:** Professional video and photography of kits and demos, trade show 
coverage
**What he needs from me:** A clear brief on what I need

## Hani — Senior Technical Staff Engineer, Academic Program
**Relationship:** Colleague and frequent trade show co-attendee
**Interaction:** Shared events, occasional logistics coordination
**What he needs from me:** Help with practical logistics — shipping, printing, etc.
**What I need from him:** Nothing substantive
**Agent notes:** Hani has deep but narrow technical knowledge and tends toward over-complicated 
explanations. When preparing content or workshops, do not incorporate his framing — the goal 
is beginner accessibility, not depth. His advice on teaching approach should be set aside in 
favour of engagement and momentum.
