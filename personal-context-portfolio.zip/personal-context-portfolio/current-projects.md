# Current Projects

## 1. PyKit Explorer — Manufacturing Launch
**Description:** A CircuitPython development kit in the form factor of a 12-inch ruler with 
serious hardware capabilities. First production run of 10,000 units.
**Status:** Hardware finalized. In manufacturing approval pipeline — multiple sign-offs 
required, progress is slow and dependent on others.
**My role:** Solo — everything from hardware through to API and workshop materials.
**Collaborators:** None on the technical side. Internal stakeholders for manufacturing approvals.
**What done looks like:** Actively in manufacturing, API complete, kits shipping globally, 
Microchip Ambassadors worldwide can run workshops with no support from me.
**Priority:** #1

## 2. PyKit Explorer API
**Description:** A high-level API sitting on top of CircuitPython that lets students build 
multiple projects in a 3-4 hour workshop and have repeated "I just built something cool" moments.
**Status:** ~80% complete. Extensive minimal code examples in progress.
**My role:** Solo.
**What done looks like:** Complete API, fully documented, with examples covering all workshop scenarios.
**Priority:** #2

## 3. Maker Faire Demos
**Description:** A suite of demos built on the PyKit Explorer — arcade games (Super Mario Bros, 
Snake, Pong, Space Invaders), musical projects (carrot piano, potato drums, theremin), and a 
balancing robot with BLE-tunable PID loop.
**Status:** Planned. Build and test phase starts when two high school interns arrive next month.
**My role:** Lead. Interns will execute much of the build and test work.
**What done looks like:** Built, tested, and shippable to the event.
**Priority:** #3

## 4. Claw Machine
**Description:** A segmented arm and gripper rig controlled via the IMU in the PyKit Explorer, 
positioned over a tub of plush toys — a crowd-friendly interactive demo.
**Status:** Planned. Blocked on collaborating engineer's team transfer.
**My role:** Co-lead with an engineer currently transferring to an adjacent team.
**What done looks like:** Built, tested, and ready to ship to the event. Interns assisting.
**Priority:** #4

## 5. PyKit Explorer Expansion Kits
**Description:** A series of add-on kits for the PyKit Explorer, including a baseboard 
designed as a trade show badge.
**Status:** Early planning.
**Priority:** #5
