# Decision Log

## How I Make Decisions

Analytical by default — gather information, map the tradeoffs, sleep on it. For decisions 
with real stakes, I talk through my thinking with more experienced engineers before committing. 
I don't decide until I have enough to know which option is least worst.

## What I Need Before I Decide

- **Hardware:** Tradeoffs between approaches — cost, complexity, capability ceiling, impact 
  on the beginner experience
- **Manufacturing:** Who needs to sign off, what the blockers are, minimum viable path through
- **Workshop/curriculum:** Clear picture of the audience — background, available tools, 
  time constraints
- **Delegation:** A read on the person's level and what will stretch without breaking them

## Decision Examples

### Car Purchase (Personal, In Progress)
**Decision:** What vehicle to buy for ski trips, scuba diving, and possible car camping.
**Constraints:** Cargo space for gear or sleeping, >35 MPG, >8 inches ground clearance, 
ideally an EREV, ~$25k budget.
**Process:** Started with cargo space, filtered by MPG, filtered by ground clearance, 
searched EREV options. Current least-worst option is a Subaru Forester. Budget excludes 
new EREVs.
**Current status:** May wait a year — EREV market is developing and budget could increase. 
Patience is the move when the ideal option doesn't exist yet.

### PyKit Explorer Hardware Specification
**Decision:** What hardware to include in the PyKit Explorer and how to fit it all on one board.
**Must-haves:** LCD display, BLE, NeoPixels, audio output (amp + speaker), SD card slot, 
IMU, CAN bus.
**Nice-to-have deferred:** Microphone (can be added via breakout board — didn't design it in).
**Non-negotiable form factor principle:** Must be something students actually keep and use — 
not something that disappears into a drawer. Back of board includes reference material: 
resistor colour code, DEC/BIN/HEX conversions, useful equations.
**Critical constraint:** LCD and SD card each needed a dedicated SPI bus for speed. BLE 
needed UART. Users needed access to SPI, I2C, UART, and CAN without sacrificing onboard 
hardware. This made SERCOM allocation the hard problem.
**Process:** Mapped SERCOM allocation in a spreadsheet against the datasheet. Slept on it. 
Then took it to Bob Martin for a sanity check before committing.

## How I Handle Uncertainty

If the right option doesn't exist yet, I wait — but only if waiting is a viable move. 
I don't force a decision to close the loop; I hold it open until I have enough. When I'm 
genuinely stuck, I go to a more experienced engineer rather than deciding alone.

## Who I Consult

Bob Martin is my primary sounding board for technical decisions with real stakes. Akram 
for anything with organizational or budget implications.
